/* SUPER EVİL — Android paketi hazırlayıcı (bağımlılıksız Node betiği).
   node prepare.js www      → game.html'i www/index.html yapar; CDN'deki three.js/cannon.js dosyalarını yerel kopyalarla değiştirir (internetsiz de çalışır)
   node prepare.js android  → `npx cap add android` sonrası: yatay mod, tam ekran, AdMob kimliği, sürüm numarası */
const fs=require("fs"), path=require("path");
const root=__dirname, mode=process.argv[2], PKG="com.notexthife.superevil";
const log=(...a)=>console.log("[prepare]",...a), fail=m=>{ console.error("[prepare] HATA:",m); process.exit(1); };

if(mode==="www"){
  const html=fs.readFileSync(path.join(root,"game.html"),"utf8"), out=path.join(root,"www"), lib=path.join(out,"lib");
  fs.rmSync(out,{recursive:true,force:true}); fs.mkdirSync(lib,{recursive:true});
  const SRC=(url)=>{ let m;
    if(/\/three\.min\.js$/.test(url)) return "node_modules/three/build/three.min.js";
    if(/cannon\.min\.js$/.test(url)) return "node_modules/cannon/build/cannon.min.js";
    if((m=url.match(/three@0\.128\.0\/examples\/js\/(.+)$/))) return "node_modules/three/examples/js/"+m[1];
    return null; };
  let n=0; const seen=new Set();
  let res=html.replace(/<script src="(https:\/\/[^"]+)"><\/script>/g,(all,url)=>{
    const rel=SRC(url); if(!rel) fail("bilinmeyen dış script: "+url);
    const from=path.join(root,rel); if(!fs.existsSync(from)) fail("dosya bulunamadı: "+rel+" (npm install --no-save three@0.128.0 cannon@0.6.2 çalıştı mı?)");
    const name=path.basename(url); if(!seen.has(name)){ fs.copyFileSync(from,path.join(lib,name)); seen.add(name); } n++; return '<script src="lib/'+name+'"></script>'; });
  if(n<5) fail("beklenenden az dış script bulundu: "+n);
  /* yapılandırma: workflow girdilerinden (boşsa dokunma) */
  const rep=(re,val,what)=>{ if(!re.test(res)) { console.warn("[prepare] UYARI: yapılandırma satırı bulunamadı:",what); return; } res=res.replace(re,val); log(what,"ayarlandı"); };
  if(process.env.AD_TEST==="true") rep(/useTest:\s*false/,"useTest:true","AdMob TEST reklamları");
  else log("AdMob: GERÇEK reklam birimi kullanılacak (useTest:false)");
  rep(/webSim:\s*true/,"webSim:false","Android'de sahte reklam kapalı");
  /* Google ile giriş + bulut kayıt: Firebase WEB ayarı oyunun içinde (config.js). Android'de yerel Google girişi için ayrıca google-services.json gerekir;
     JS SDK her zaman web anahtarını kullanır (Android anahtarı uygulama imzasına kilitli olduğundan WebView'dan çalışmaz). Burada yalnızca tutarlılığı denetliyoruz. */
  const gs=path.join(root,"google-services.json"), mp=res.match(/projectId:\s*"([^"]+)"/), cfgPid=mp&&mp[1];
  if(!cfgPid) console.warn("[prepare] UYARI: oyunda Firebase projectId yok → Google girişi/bulut kayıt çalışmaz");
  else log("Firebase projesi (oyun içi web ayarı):",cfgPid);
  if(fs.existsSync(gs)){
    try{ const g=JSON.parse(fs.readFileSync(gs,"utf8")), pid=g.project_info&&g.project_info.project_id;
      const cl=(g.client||[]).find(c=>c.client_info&&c.client_info.android_client_info&&c.client_info.android_client_info.package_name===PKG)||null;
      if(!cl) fail("google-services.json içinde '"+PKG+"' paketi yok. Firebase'de Android uygulamasını bu paket adıyla ekleyip dosyayı yeniden indir.");
      if(cfgPid&&pid!==cfgPid) fail("google-services.json projesi ('"+pid+"') oyundaki Firebase projesiyle ('"+cfgPid+"') aynı değil.");
      if(!(cl.oauth_client||[]).some(o=>o.client_type===3)) console.warn("[prepare] UYARI: google-services.json'da web OAuth istemcisi (client_type 3) yok → Android'de Google girişi çalışmaz. Firebase → Authentication → Sign-in method → Google'ı AÇ, SHA-1'leri ekle, dosyayı SONRA yeniden indir.");
      log("google-services.json doğrulandı ("+pid+") → Android'de yerel Google girişi açılacak");
    }catch(e){ fail("google-services.json okunamadı: "+e.message); } }
  else console.warn("[prepare] UYARI: google-services.json yok → Android uygulamasında Google girişi çalışmaz (düğme 'yapılandırılmamış' der). Rehber ADIM 7.");
  if(process.env.PRIVACY_URL) rep(/privacyUrl:\s*""/,"privacyUrl:"+JSON.stringify(process.env.PRIVACY_URL),"gizlilik politikası bağlantısı");
  if(process.env.SUPPORT_MAIL) rep(/supportMail:\s*""/,"supportMail:"+JSON.stringify(process.env.SUPPORT_MAIL),"destek e-postası");
  fs.writeFileSync(path.join(out,"index.html"),res); log("www hazır, yerel kütüphane:",[...seen].join(", "));
  process.exit(0);
}

if(mode==="android"){
  const A=path.join(root,"android"); if(!fs.existsSync(A)) fail("android/ klasörü yok (önce: npx cap add android)");
  const walk=(d,f,acc=[])=>{ for(const e of fs.readdirSync(d,{withFileTypes:true})){ const p=path.join(d,e.name); if(e.isDirectory()){ if(e.name==="build"||e.name==="node_modules") continue; walk(p,f,acc); } else if(f(p)) acc.push(p); } return acc; };
  let warn=0; const W=m=>{ warn++; console.warn("[prepare] UYARI:",m); };
  /* 1) AndroidManifest: yatay mod + AdMob uygulama kimliği */
  const man=path.join(A,"app/src/main/AndroidManifest.xml"); let mx=fs.readFileSync(man,"utf8");
  const APPID="ca-app-pub-1648586598987752~6369370670";
  if(!/com\.google\.android\.gms\.ads\.APPLICATION_ID/.test(mx)){ if(!/<\/application>/.test(mx)) W("manifest: </application> yok"); else mx=mx.replace("</application>",'    <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="'+APPID+'"/>\n    </application>'); }
  if(!/screenOrientation=/.test(mx)){ if(/<activity\b/.test(mx)) mx=mx.replace(/<activity\b/,'<activity\n            android:screenOrientation="sensorLandscape"'); else W("manifest: <activity> yok"); }
  else mx=mx.replace(/android:screenOrientation="[^"]*"/,'android:screenOrientation="sensorLandscape"');
  fs.writeFileSync(man,mx); log("manifest güncellendi (yatay mod + AdMob kimliği)");
  /* 2) MainActivity: tam ekran (sistem çubukları gizli), ekran kapanmasın */
  const mains=walk(path.join(A,"app/src/main/java"),p=>/MainActivity\.java$/.test(p));
  if(!mains.length) W("MainActivity.java bulunamadı"); else { const f=mains[0], src=fs.readFileSync(f,"utf8"), pk=(src.match(/^\s*package\s+([\w.]+)\s*;/m)||[])[1];
    if(!pk) W("MainActivity paket adı okunamadı"); else { fs.writeFileSync(f,`package ${pk};

import android.os.Bundle;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideBars();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    private void hideBars() {
        try {
            WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
            WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
            c.hide(WindowInsetsCompat.Type.systemBars());
            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        } catch (Throwable ignored) { }
    }
}
`); log("MainActivity tam ekran olarak yazıldı:",path.relative(A,f)); } }
  /* 2b) Google girişi/bulut kayıt: google-services.json + eklenti değişkeni (yalnızca dosya varsa) */
  const gs=path.join(root,"google-services.json");
  if(fs.existsSync(gs)){
    fs.copyFileSync(gs,path.join(A,"app/google-services.json")); log("google-services.json → android/app/");
    const vg=path.join(A,"variables.gradle");
    if(!fs.existsSync(vg)) W("variables.gradle yok (Google girişi için rgcfaIncludeGoogle eklenemedi)");
    else { let v=fs.readFileSync(vg,"utf8"); if(!/rgcfaIncludeGoogle/.test(v)){ if(/ext\s*\{/.test(v)){ v=v.replace(/ext\s*\{/,"ext {\n    rgcfaIncludeGoogle = true"); fs.writeFileSync(vg,v); log("variables.gradle: rgcfaIncludeGoogle = true"); } else W("variables.gradle: ext { } bloğu yok"); } }
    if(!fs.existsSync(path.join(root,"node_modules/@capacitor-firebase/authentication"))) W("@capacitor-firebase/authentication kurulu değil → uygulamada Google girişi çalışmaz");
  } else log("google-services.json yok: Firebase eklentisi eklenmedi");
  /* 3) sürüm: versionCode her derlemede artar (Play zorunlu kılar) */
  const bg=path.join(A,"app/build.gradle"); let g=fs.readFileSync(bg,"utf8"); const code=process.env.VERSION_CODE||"1", name=process.env.VERSION_NAME||"1.0.0";
  if(/versionCode\s+\d+/.test(g)) g=g.replace(/versionCode\s+\d+/,"versionCode "+code); else if(/versionCode\s*=\s*\d+/.test(g)) g=g.replace(/versionCode\s*=\s*\d+/,"versionCode = "+code); else W("build.gradle: versionCode bulunamadı");
  if(/versionName\s+"[^"]*"/.test(g)) g=g.replace(/versionName\s+"[^"]*"/,'versionName "'+name+'"'); else if(/versionName\s*=\s*"[^"]*"/.test(g)) g=g.replace(/versionName\s*=\s*"[^"]*"/,'versionName = "'+name+'"'); else W("build.gradle: versionName bulunamadı");
  fs.writeFileSync(bg,g); log("sürüm:",name,"("+code+")");
  log(warn?("tamamlandı, "+warn+" uyarı"):"tamamlandı"); process.exit(0);
}
fail("kullanım: node prepare.js www | android");
